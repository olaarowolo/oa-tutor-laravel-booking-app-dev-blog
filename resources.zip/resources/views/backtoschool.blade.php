@extends('layouts.app')
@include('components.head')
@include('partials.header')
@section('title', 'Back to School Registration (Summer Term 2025)')
{{-- @include('components.slider') --}}
@include('components.backtoschool')
@section('content')

@endsection
