<h2>New Registration: Back to School Tuition (Summer Term 2025)</h2>

<p><strong>Parent/Guardian Name:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Phone:</strong> {{ $phone }}</p>

<hr>

<p><strong>Child’s Full Name:</strong> {{ $child_name }}</p>
<p><strong>Key Stage/Exam:</strong> {{ $stage }}</p>
<p><strong>Year Group:</strong> {{ $year_group }}</p>
<p><strong>Age:</strong> {{ $child_age }}</p>
